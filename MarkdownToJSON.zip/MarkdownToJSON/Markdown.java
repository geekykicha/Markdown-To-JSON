import java.io.*;

public class Markdown {

    // Method to convert a Markdown file to JSON format.
    public static String mdToJson(String path) throws IOException {
        StringBuilder out = new StringBuilder("[\n");  // Start a JSON array with an opening bracket and newline.
        
        // Open the Markdown file for reading.
        try (BufferedReader r = new BufferedReader(new FileReader(path))) {
            String ln;
            
            // Loop through each line of the file.
            while ((ln = r.readLine()) != null) {
                ln = ln.trim();  // Remove extra spaces from the start and end of the line.
                
                // Check if the line starts with headers ("#"), list items ("- "), or other content.
                out.append(ln.startsWith("#") ? fmt("header", ln.startsWith("##") ? 2 : 1, ln.replaceFirst("#+ ", "")) :
                          ln.startsWith("- ") ? "{\"type\":\"list\",\"items\":" + getItems(r, ln) + "},\n" : 
                          ln.isEmpty() ? "" : content(ln));  // Append formatted output to the JSON array.
            }
        }
        
        // If the output has content, remove the trailing comma and close the array. Otherwise, return an empty array.
        return out.length() > 2 ? out.deleteCharAt(out.length() - 2).append("\n]").toString() : "[]";
    }

    // Helper method to format headers.
    private static String fmt(String t, int l, String txt) {
        // Formats the header type, level (1 or 2), and text into JSON format.
        return String.format("{\"type\":\"%s\",\"level\":%d,\"text\":\"%s\"},\n", t, l, txt);
    }

    // Method to collect and format list items from the Markdown file.
    private static String getItems(BufferedReader r, String ln) throws IOException {
        // Start creating a JSON array for list items.
        StringBuilder items = new StringBuilder("[\"").append(ln.substring(2).trim()).append("\"");
        
        // Read more lines as long as they start with "- " (indicating more list items).
        while ((ln = r.readLine()) != null && ln.trim().startsWith("- ")) {
            items.append(",\"").append(ln.substring(2).trim()).append("\"");  // Add each list item to the array.
        }
        return items.append("]").toString();  // Close the list array and return it.
    }

    // Method to handle different content types (links, images, or plain paragraphs).
    private static String content(String ln) {
        // Check if the content is a link and format it accordingly.
        if (ln.contains("[") && ln.contains("](")) {
            return String.format("{\"type\":\"link\",\"text\":\"%s\",\"url\":\"%s\"},\n",
                    ln.substring(ln.indexOf("[") + 1, ln.indexOf("]")), ln.substring(ln.indexOf("(") + 1, ln.indexOf(")")));
        }
        // Check if the content is an image and format it accordingly.
        if (ln.contains("![") && ln.contains("](")) {
            return String.format("{\"type\":\"image\",\"altText\":\"%s\",\"url\":\"%s\"},\n",
                    ln.substring(ln.indexOf("![") + 2, ln.indexOf("]")), ln.substring(ln.indexOf("(") + 1, ln.indexOf(")")));
        }
        // If the content is a plain paragraph, format it as text.
        return String.format("{\"type\":\"paragraph\",\"text\":\"%s\"},\n", ln);
    }

    // Method to write the generated JSON to a file.
    public static void writeToFile(String json, String path) throws IOException {
        // Open the file for writing and write the JSON content into it.
        try (BufferedWriter w = new BufferedWriter(new FileWriter(path))) {
            w.write(json);  // Write the JSON string to the file.
        }
    }

    // Main method where the program execution begins.
    public static void main(String[] args) {
        try {
            // Convert the "Markdown.md" file to JSON and save it as "output.json".
            writeToFile(mdToJson("Markdown.md"), "output.json");
        } catch (IOException e) {
            e.printStackTrace();  // Print error details if something goes wrong.
        }
    }
}


